---
title: Predict Voucher Redemption Rate
layout: note
image: .jpg
description: description description description
category: info
tags:
  - tag
  - tag
---

# intro
i've been working on voucher recommendation for the past few months,

# features
-
