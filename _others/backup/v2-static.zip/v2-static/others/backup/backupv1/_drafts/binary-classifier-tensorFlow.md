---
title: Binary classifier with TensorFlow
layout: note
image: https://www.udemycouponpro.com/wp-content/uploads/2018/08/Data-Science-in-Python-Pandas-Scikit-learnNumpy-Matplotlib-udemy-coupon-pro-ucp.jpg
description: to be completed
category: info
tags:
  - tag
  - tag
---

# Features

## Customizable theme
The theme can be customized just by `changing` few variables in **_config.yml** file.

## Lightweight
Since the theme is based on default Jekyll theme, it is very lightweight. No JavaScript except analytics is used!
