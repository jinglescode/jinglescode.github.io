git pull https://github.com/jinglescode/jinglescode.github.io.git master
