git add -A
git commit -m "$1"
git push https://github.com/jinglescode/jinglescode.github.io.git master
