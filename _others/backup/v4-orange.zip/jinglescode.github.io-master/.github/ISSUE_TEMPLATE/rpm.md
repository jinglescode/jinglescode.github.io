---
name: RPM
about: Daily RPM
title: 'RPM: MTH DAY 2020'
labels: RPM
assignees: ''

---

# Work

**Result**
Thought leader in my field of machine learning. To publish in top journals and conferences. To be desirable by top companies in the world. To create an impact on the world with my research. MIT TR35 inventor. Write for Nature.

**Purpose**
- 

**Actions**
- [ ] 

# Writing

**Result**
To make massive progress to become a thought leader in my field of machine learning. To achieve 'Top Writer' in 'Machine Learning', 'Data Science' and 'Artificial Intelligence' by the end of the year. To achieve 1000 followers by the end of the year.

**Purpose**
- 

**Actions**
- [ ]
