---
name: Research readings
about: Notes of academic papers I've read
title: ''
labels: research
assignees: ''

---

# TL;DR


## Paper Link


# Details

## Overview


## Contributions and Distinctions from Previous Works


## Methods


## Results


## Comments
