
what the book is about
what application i get out of it


# unlimited power

# awaken the giant within


# Steve jobs
about perfection and looking at the details, even on those details that no one look at


# the ride of a lifetimme

Bob Iger is a humble CEO
his personal story


# Outlier

success dont just happen, it takes a lot of contributing factors for success to happen.
bill gates, steve jobs and many others, they work hard (10000 hours), to master the craft of something.
and when oppunity comes, they are at their best, to catch onto the ride
